# Importa os modulos
import os

# Limpa o CMD
if os.name == "nt":
    os.system("@cls & @title Overload DDOS Tool by: Nuvem & @color e")
else:
    os.system("clear")
